# Stanley Cup Game (Web App)

A simple web game where you're shown 10 random NHL teams and must keep their combined Stanley Cup wins under 10. You can skip one team.

## Features
- Built with Flask and HTML/JS
- Random NHL team draws
- One allowed skip
- Win if total Stanley Cups < 10

## How to Run Locally

```bash
pip install flask
python app.py
```

Open your browser at `http://localhost:5000`.

## Deploy

Can be deployed to:
- Replit
- Render
- PythonAnywhere
