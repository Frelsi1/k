from flask import Flask, render_template, session, jsonify, request
import random

app = Flask(__name__)
app.secret_key = 'verysecretkey'

teams_cup_totals = {
    "Montreal Canadiens": 24,
    "Toronto Maple Leafs": 13,
    "Detroit Red Wings": 11,
    "Boston Bruins": 6,
    "Chicago Blackhawks": 6,
    "Edmonton Oilers": 5,
    "Pittsburgh Penguins": 5,
    "New York Islanders": 4,
    "New York Rangers": 4,
    "New Jersey Devils": 3,
    "Colorado Avalanche": 3,
    "Tampa Bay Lightning": 3,
    "Philadelphia Flyers": 2,
    "Los Angeles Kings": 2,
    "Dallas Stars": 1,
    "Calgary Flames": 1,
    "Carolina Hurricanes": 1,
    "Anaheim Ducks": 1,
    "St. Louis Blues": 1,
    "Florida Panthers": 1,
    "Vancouver Canucks": 0,
    "Buffalo Sabres": 0,
    "Ottawa Senators": 0,
    "San Jose Sharks": 0,
    "Winnipeg Jets": 0,
    "Minnesota Wild": 0,
    "Columbus Blue Jackets": 0,
    "Arizona Coyotes": 0,
    "Nashville Predators": 0,
    "Seattle Kraken": 0
}

@app.route('/')
def index():
    session['teams'] = random.sample(list(teams_cup_totals.items()), len(teams_cup_totals))
    session['index'] = 0
    session['selected'] = []
    session['total_cups'] = 0
    session['skip_used'] = False
    return render_template('index.html')

@app.route('/next_team')
def next_team():
    if session['index'] >= len(session['teams']):
        return jsonify({'done': True})
    team, cups = session['teams'][session['index']]
    return jsonify({'team': team, 'cups': cups})

@app.route('/select', methods=['POST'])
def select():
    team, cups = session['teams'][session['index']]
    session['selected'].append(team)
    session['total_cups'] += cups
    session['index'] += 1
    return jsonify({
        'selected': team,
        'cups': cups,
        'total_cups': session['total_cups'],
        'done': len(session['selected']) >= 10
    })

@app.route('/skip', methods=['POST'])
def skip():
    if session['skip_used']:
        return jsonify({'error': 'Skip already used'})
    session['skip_used'] = True
    skipped_team = session['teams'][session['index']][0]
    session['index'] += 1
    return jsonify({'skipped': skipped_team})

@app.route('/result')
def result():
    win = session['total_cups'] < 10
    return jsonify({
        'win': win,
        'total_cups': session['total_cups'],
        'selected_teams': session['selected']
    })

if __name__ == '__main__':
    app.run(debug=True)
